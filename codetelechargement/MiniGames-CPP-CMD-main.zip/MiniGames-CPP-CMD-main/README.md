For best results, it's best to run Executable.exe in a GitBash window.
